README

This project uses Python 3.4.

No external libraries were used for this project. All imports are included in Python 3.4. 

To run this project, simply call the function and inputs in the command prompt. 